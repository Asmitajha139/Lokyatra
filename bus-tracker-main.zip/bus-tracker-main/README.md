# Lok Yatra: A Real-Time Public Transport Ecosystem

<div align="center">

![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)
![Express.js](https://img.shields.io/badge/Express.js-000000?style=for-the-badge&logo=express&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)
![Socket.io](https://img.shields.io/badge/Socket.io-010101?style=for-the-badge&logo=socketdotio&logoColor=white)

</div>

## 📖 Overview

Lok Yatra is a comprehensive, real-time logistics platform designed to modernize public bus transport networks in India's emerging smart cities. This full-stack solution addresses the critical lack of reliable transit information by creating a transparent, efficient, and inclusive ecosystem for passengers, bus staff, and transport administrators.

## 📽️Video Representataion

[Watch Video](https://drive.google.com/file/d/17YNZPYkkkY7wxMgwtxNKTOAddkmbMG0j/view?usp=drive_link)


## ✨ Core Features

### 🚶 Passenger Portal

* **Secure Authentication**: Passwordless login using phone number with automatic account creation
* **Intelligent Search**: Responsive, mobile-first interface with autocomplete suggestions and location swap functionality
* **Live Tracking Dashboard**: Clean interface displaying searched routes, live maps, and real-time bus information
* **Real-Time ETA**: Accurate estimated time of arrival calculated using advanced geospatial algorithms
* **Network Overview**: Interactive map showing all available bus routes in the city
* **Profile Management**: Secure portal for updating personal details and emergency contacts
* **Emergency SOS**: Press-and-hold SOS feature generating pre-formatted SMS alerts to administrators and emergency contacts

### 👨‍✈️ Staff Portal (Bus Conductors)

* **Role-Based Authentication**: Secure username/password login for authorized staff only
* **Smart Dashboard**: Automatic identification of logged-in staff and assigned bus
* **Controlled Tracking**: Explicit "Start Live Tracking" button for location broadcasting control
* **High-Fidelity GPS**: Intelligent signal filtering and location smoothing for stable, reliable tracking
* **Self-Verification**: Real-time map and coordinate display for location verification

### ⚙️ Administrator Portal

* **Comprehensive Dashboard**: Multi-panel Single-Page Application for complete network management
* **Full CRUD Operations**: Create, Read, Update, and Delete functionality for Routes, Buses, and Staff
* **Dual-Mode Route Creator**: 
  - Manual route drawing on interactive maps
  - Automatic optimal path generation using OpenRouteService API
* **Relational Management**: Intuitive interface for assigning staff to buses and buses to routes
* **Network Visualization**: Unified view of all routes on a single interactive map

## 🏗️ System Architecture

**Backend**: Node.js with Express framework, modular logic separation for admin, user, and staff functions

**Database**: Local MongoDB with Mongoose ODM for data persistence

**Real-Time Engine**: Socket.IO for live GPS tracking and administrative commands

**Frontend**: Multi-Page Application (MPA) for passengers, Single-Page Application (SPA) for administrators, built with vanilla JavaScript, HTML5, and CSS3

**Security**: JWT-based role authentication with bcryptjs password hashing

## 🛠️ Technology Stack

| Category | Technology |
|----------|------------|
| **Frontend** | HTML5, CSS3, Vanilla JavaScript, Leaflet.js |
| **Backend** | Node.js, Express.js |
| **Database** | MongoDB, Mongoose ODM |
| **Real-Time** | Socket.IO |
| **Authentication** | JSON Web Tokens (JWT), bcryptjs |
| **Geospatial** | Turf.js (ETA calculations), OpenRouteService API (route optimization) |

## 🚀 Getting Started

### Prerequisites

* [Node.js](https://nodejs.org/) (v16 or later)
* [MongoDB Community Server](https://www.mongodb.com/try/download/community) installed and running locally

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/lok-yatra.git
   cd lok-yatra
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   
   Create a `.env` file in the project root:
   ```env
   # MongoDB connection string
   MONGO_URI=mongodb://localhost:27017/bus-tracker
   
   # JWT secret key (use a long, random string)
   JWT_SECRET=your_super_secret_jwt_key_here_12345
   
   # OpenRouteService API key
   ORS_API_KEY=your_openrouteservice_api_key_here
   ```
   
   > Get your OpenRouteService API key from [OpenRouteService](https://openrouteservice.org/)

4. **Start the server**
   ```bash
   npm start
   ```
   
   The server will be available at `http://localhost:3000`

### Access Points

* **Passenger & Staff Login**: `http://localhost:3000/`
* **Admin Dashboard**: `http://localhost:3000/admin.html`

## 📁 Project Structure

```
.
├── middleware/
│   └── auth.js                 # Authentication middleware
├── models.js                   # MongoDB schemas
├── public/
│   ├── components/
│   │   └── navbar.html         # Reusable navigation component
│   ├── images/
│   │   ├── bus.png
│   │   ├── login-bg.jpg
│   │   └── logo.png
│   ├── admin.html              # Admin dashboard
│   ├── bus.html                # Staff tracking interface
│   ├── emergency.html          # Emergency SOS page
│   ├── homepage.html           # Passenger search page
│   ├── index.html              # Login page
│   ├── navbar.js               # Navigation logic
│   ├── profile.html            # User profile management
│   ├── route-map.html          # Network overview map
│   └── tracking.html           # Live tracking dashboard
├── routes/
│   ├── admin.js                # Admin API routes
│   ├── staff.js                # Staff API routes
│   └── user.js                 # User API routes
├── utils/
│   └── etaCalculator.js        # ETA calculation logic
├── server.js                   # Main server file
├── .env                        # Environment variables
├── .gitignore
├── package.json
└── package-lock.json
```

## 🔮 Future Roadmap

* **Cloud Deployment**: Migration to cloud platforms (Render, MongoDB Atlas) for public accessibility
* **IVR Integration**: Interactive Voice Response system for users without smartphones
* **SMS Fallback**: Offline SMS tracking for conductors in no-network zones
* **Analytics Dashboard**: Historical route analysis, bottleneck identification, and schedule optimization

## 📝 License

This project is licensed under the MIT License.

## 🤝 Contributing

Contributions, issues, and feature requests are welcome! Feel free to check the [issues page](https://github.com/vanshtyagi001/bus-tracker/issues).

## 🙏 Acknowledgments

* OpenRouteService for routing API
* Leaflet.js for mapping functionality
* Turf.js for geospatial calculations
